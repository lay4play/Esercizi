// autore : paolo
// versione e data: 1 del 10-08-2013
// descrizione :  lettura e scrittura di due numeri
// Sviluppato con: Dev-C++ 5.4.1               
#include <stdio.h>
main()
{
 int num1, num2;
  printf("Programma che calcola il prodotto di due numeri");
  printf("\nInserisci il moltiplicando   : ");
  scanf ("%d", &num1);
  printf("Inserisci il moltiplicatore  : ");
  scanf ("%d", &num2);
  printf("Il prodotto calcolato e\'     : %d", num1*num2);
  
  printf("\n\n");
}
 
