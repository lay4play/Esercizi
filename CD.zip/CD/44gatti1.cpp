// autore : paolo
// versione e data: 1 del 10-08-2013
// descrizione : formattazione e scrittura di stringhe 
// Sviluppato con: Dev-C++ 5.4.1     
#include <iostream>
main()
{
  printf(" 44 gatti");
  printf(" in fila per 6 col resto di 2 ");
  printf("\n\n");
  printf(" 6 x 7 = 42, piu' 2 fa 44");
  
  printf("\n\n");  
 }
