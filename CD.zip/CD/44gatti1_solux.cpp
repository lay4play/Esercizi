// Sviluppato con: Dev-C++ 5.4.1     
#include <iostream>  
// #include <cstdlib> 
using namespace std;
main()
{
  float gatti1,gatti2,gatti3,gatti4,gatti5;

  gatti1  = 44;
  gatti2  =  6;
  gatti3  =  2;
  gatti4  =  7;
   
  cout << gatti1 << " gatti ";
  cout << "\n in fila per " << gatti2 << " col resto di " << gatti3;
  cout << "\n  "  << gatti2 << " x";
  cout << "\n  "  << gatti4<< " =";
  cout << "\n 42 "  <<" piu' " << gatti3 <<" fa " << gatti1;
      
  cout << "\n\n";
 // system("PAUSE");	
}
