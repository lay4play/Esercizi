// Sviluppato con: Dev-C++ 5.4.1                 
#include <stdio.h>
main()
{
  system("TITLE Nome colorato");
  system("COLOR 2e");
  printf("\n  Ciao, io sono Paolo\n");

  system("PAUSE");

  system("CLS");
  printf("\n system(\"COLOR fc\")imposta il nome rosso su sfondo bianco\n\n");
  system("PAUSE");
  system("COLOR fc");
  system("CLS");
  printf("\n  Ciao, io sono Paolo\n");
  system("PAUSE");

  printf("\n system(\"COLOR cf\")imposta il nome bianco su sfondo rosso\n\n");
  system("PAUSE");
  system("CLS");
  printf("\n  Ciao, io sono Paolo\n");
  system("COLOR cf");
  system("PAUSE");

  printf("\n system(\"COLOR 17\")imposta il nome grigio chiaro su sfondo blu\n\n");
  system("PAUSE");
  system("CLS");
  printf("\n  Ciao, io sono Paolo\n");
  system("COLOR 17");
  system("PAUSE");

  printf("\n system(\"COLOR 71\")imposta il nome blu su sfondo grigio chiaro\n\n");
  system("PAUSE");
  system("COLOR 71");
  system("CLS");
  printf("\n  Ciao, io sono Paolo\n");
  system("PAUSE");

  printf("\n system(\"COLOR f2\")imposta il nome verde su sfondo bianco\n\n");
  system("PAUSE");
  system("COLOR f2");
  system("CLS");
  printf("\n  Ciao, io sono Paolo\n");
  system("PAUSE");

  printf("\n system(\"COLOR 2f\")imposta il nome bianco su sfondo verde\n\n");
  system("PAUSE");
  system("COLOR 2f");
  system("CLS");
  printf("\n  Ciao, io sono Paolo\n");


  printf("\n\n");
}

