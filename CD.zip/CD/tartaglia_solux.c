// autore : paolo
// versione e data: 1 del 10-08-2018
// descrizione : disegna il triangolo di Tartaglia
// Sviluppato con: Dev-C++ 5.4.1               
#include <stdio.h>

main()
{

  printf("\n\t      1");
  printf("\n\t    1 2 1");
  printf("\n\t   1 3 3 1");
  printf("\n\t  1 4 6 4 1");
  printf("\n\t 1 5 10 10 1");
  
  printf("\n\n    Triangolo di Tartaglia\n\n");

// system("PAUSE");	
}
