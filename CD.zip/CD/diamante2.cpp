// autore : paolo
// versione e data: 1 del 10-12-2014
// descrizione : disegna cinque diamanti 
// Sviluppato con  : Dev-C++ 5.4.1     
#include <iostream>  
// #include <cstdlib>             // per includere la funzione system
using namespace std;

main()
{
  cout << "   *     *   \n";
  cout << "  ***   ***  \n";
  cout << " ***** ***** \n";
  cout << "  ***   ***  \n";
  cout << "   *  *  *   \n";
  cout << "     ***     \n";
  cout << "    *****    \n";
  cout << "     ***     \n";
  cout << "   *  *  *   \n";
  cout << "  ***   ***  \n";
  cout << " ***** ***** \n";
  cout << "  ***   ***  \n";
  cout << "   *     *   \n";

  printf("\n\n");
//  system("PAUSE");
}
