// autore : paolo
// versione e data: 1 del 10-08-2014
// descrizione :  scrittura di stringhe 
// Sviluppato con: Dev-C++ 5.4.1                 
#include <stdio.h>
main()
{
  int gatti1,gatti2,gatti3,gatti4,gatti5;

  gatti1  = 44;
  gatti2  =  6;
  gatti3  =  2;
  gatti4  =  7;
  printf(" %d gatti ", gatti1);
  printf(" in fila per %d col resto di %d ", gatti2, gatti3);
  printf(" \n\n");
  printf(" %d x %d = %d, piu' %d fa %d", gatti2, gatti4, 42, gatti3, gatti1);
      
  printf("\n\n");
}
