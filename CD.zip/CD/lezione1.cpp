/* Sviluppato con  : Dev-C++ 5.4.1    */
#include <iostream>   // include le funzioni di IO
using namespace std;
#include <conio.h>    // include le funzioni get()
#include <cstdlib>    // include le funzioni system
main() 
{
  cout << "ciao mondo C++ (o CPP)" ;
   
  cout << "\n\n" ; 
  
// sono inutili, dato che dalla versione 5.4.1 si ferma da solo!
  getch();  

  system("PAUSE"); 
}


/* versione minimale del programma 
#include <iostream>   // include le funzioni di IO
using namespace std;
main() 
{
  cout << "ciao mondo C++ (o CPP)" ;
   
  cout << "\n\n" ;   
}
*/

