// autore : paolo
// versione e data: 1 del 10-08-2013
// descrizione :  lettura e scrittura di due numeri
// Sviluppato con: Dev-C++ 5.4.1  
#include <stdio.h>
main()
{
 int num1, num2;

  scanf ("%d%d", &num1,&num2);
  printf("%d \n", num1*num2);

  printf("\n\n");
}
 
