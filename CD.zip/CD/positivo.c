#include <stdio.h>
main()
{
 int num1;
  printf ("Inserisci un numero  \t: ");
   scanf ("%d", &num1);
  if (num1 >= 0)
   printf ("il numero %d e' positivo" , num1);
  else
   printf ("il numero %d e' negativo", num1);
}


/* File: positivo.c                           */
/* Time-stamp: "2018-06-06 03:26:06 paolo"    */
/* Scopo: uso di if/else                      */
// Sviluppato con: Dev-C++ 5.11       
