/* File: boolean1.c */
/* Time-stamp: "2013-06-06 03:26:06 paolo"      */
/* Scopo: uso delle variabili bool              */
// Sviluppato con: Dev-C++ 5.4.1    
#include <stdio.h>
#include <stdbool.h>
main()
{
//variabili locali alla funzione main
  bool piove;
//istruzioni della funzione main
  piove=true;
  if (piove)
    printf("apri l'ombrello"); 
    
  printf("\n\n");
}
