#include <iostream>     
using namespace std;
int main(){
 system("TITLE COLORI");
 system("CLS");
 system("COLOR 2e");
 cout << "  0 = Nero           8 = Grigio\n" ;
 cout << "  1 = Blu scuro      9 = Blu\n" ;
 cout << "  2 = Verde          A = Verde limone\n";
 cout << "  3 = Verde acqua    B = Azzurro\n" ;
 cout << "  4 = Bordeaux       C = Rosso\n" ;
 cout << "  5 = Viola          D = Fucsia\n";
 cout << "  6 = Verde oliva    E = Giallo\n";
 cout << "  7 = Grigio chiaro  F = Bianco\n\n";  
 cout << "\n\n";
}


// autore          : paolo
// versione e data : 1 del 22-05-2018
// descrizione     : gestione dei colori 
// Sviluppato con  : Dev-C++ 5.11 
