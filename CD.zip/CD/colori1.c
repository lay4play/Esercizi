// autore : paolo
// versione e data: 1 del 10-08-2018
// descrizione :  gestione dei colori 
// Sviluppato con: Dev-C++ 5.11                 
#include <stdio.h>
main()
{
  system ("CLS");
  system ("COLOR 2e");
  printf("    0 = Nero           8 = Grigio\n");
  printf("    1 = Blu scuro      9 = Blu\n");
  printf("    2 = Verde          A = Verde limone\n");
  printf("    3 = Verde acqua    B = Azzurro\n");
  printf("    4 = Bordeaux       C = Rosso\n");
  printf("    5 = Viola          D = Fucsia\n");
  printf("    6 = Verde oliva    E = Giallo\n");
  printf("    7 = Grigio chiaro  F = Bianco\n\n");
  getch();
}
