#include <iostream>   // include le funzioni di IO
#include <conio.h>    // include le funzioni get()
int main() {
  system ("CLS");
  system ("COLOR 90");
  printf("\n INTER ");
  system("PAUSE");
  system ("COLOR C0");
  printf("\n MILAN ");
  system("PAUSE");
  system ("COLOR EC");
  printf("\n ROMA  ");
  system("PAUSE");
  system ("COLOR BF");
  printf("\n NAPOLI ");
  
  printf("\n\n");
  system("PAUSE");

}
