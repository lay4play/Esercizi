// Sviluppato con: Dev-C++ 5.4.1                 
#include <stdio.h>  // in comune a C e C++
main()
{
  printf ("ciao mondo C");
  printf("\n\n");
}
