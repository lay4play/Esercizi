// autore : paolo
// versione e data: 1 del 10-08-2018
// descrizione : disegna un albero di natale
// Sviluppato con: Dev-C++ 5.4.1                 
#include <stdio.h>
main()
{

  printf("\n\t       ^       ");
  printf("\n\t      / \\     ");
  printf("\n\t     /*  \\    ");
  printf("\n\t    /  *  \\   ");
  printf("\n\t   / *   * \\  ");
  printf("\n\t  /    *   *\\ ");
  printf("\n\t  / *   *  *\\ ");
  printf("\n\t  /___*  ___\\ ");
  printf("\n\t      |_|");
  
  printf("\n\n\t Buon Natale!\n\n");

//  system("PAUSE");	
}
