// Autore: paolo camagni - classe IC 
#include <iostream>
using namespace std;
int main(){

  printf("Ciao mondo C");
	
	printf("\n\n");
}


