// Autore:
#include <iostream>
using namespace std;

int main(){

 cout << "\n Leonardo Pisano, detto il \"Fibonacci\"\n";
 
 cout << "\n Leonardo Pisano, \n\tdetto il \"Fibonacci\"\n";
  
 system("PAUSE");

 cout << "\a\a";

 system("DIR");
 
 system("CALC	");

}

