#include <stdio.h>
// parola chiave const
const int MIN = 1;
const int MAX = 10;
const float PI = 3.1515;
const char A ='A';


