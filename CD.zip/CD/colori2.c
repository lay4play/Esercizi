// autore : paolo
// versione e data: 1 del 10-08-2013
// descrizione :  gestione dei colori 
// sviluppato con: Dev-C++ 5.4.1                 
 
#include <stdio.h>
main()
{
  printf("\nInizializzo lo sfondo BLU (1) e la scritta VERDE (A):\n");
  printf("system(\"COLOR 1A\")\n\n");
  system("COLOR 1A");

  printf("\nAssegno il nome alla finestra:\n");
  printf("system(\"TITLE Nome finestra colorata\")\n\n");
  system("TITLE Nome finestra colorata");

}

