// Autore: paolo camagni - classe ID 
#include <iostream>
using namespace std;
int main(){

  cout << "Ciao mondo C++ (o CPP)";
	
	cout << ("\n\n");
}



