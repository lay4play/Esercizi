#include <iostream>     // libreria per l'IO
using namespace std;    // spazio dei nomi

int main(){
 double area;
 cout << "\nCalcolo area del cerchio";
 area =  10 * 10 * 3.1415;
 cout <<"\n valore:  area = " << area; 
 cout <<"\n PI =  "<< 3.1415 << " r = "<< 10 ;
}

// autore : paolo
// versione e data: 1 del 10-08-2013
// descrizione : calcolo dell'area di un cerchio senza uso di costanti
// Sviluppato con: Dev-C++ 5.4.1    
