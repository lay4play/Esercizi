// autore : paolo
// versione e data: 1 del 10-08-2018
// descrizione : disegna un albero di natale
// Sviluppato con: Dev-C++ 5.4.1                 
#include <iostream>
using namespace std;
int main(){

  cout <<"\n\t       ^       ";
  cout <<"\n\t      / \\     ";
  cout <<"\n\t     /*  \\    ";
  cout <<"\n\t    /  *  \\   ";
  cout <<"\n\t   / *   * \\  ";
  cout <<"\n\t  /    *   *\\ ";
  cout <<"\n\t  / *   *  *\\ ";
  cout <<"\n\t  /___*  ___\\ ";
  cout <<"\n\t      |_|";
  
  cout <<"\n\n\t Buon Natale!\n\n";

//  system("PAUSE");	
}
