/* File: negazioneSol.c                         */
/* Time-stamp: "2013-06-06 03:26:06 paolo"      */
/* Scopo: uso operatore logico not              */
// Sviluppato con: Dev-C++ 5.4.1                 
#include <stdio.h>
#include <stdbool.h>   
main()
{
//variabili locali alla funzione main
  bool piove;
//istruzioni della funzione main
  piove = false;
  if ( !piove )
    printf("non piove"); 
  else
    printf("apri l'ombrello"); 

  printf("\n\n");
 // system("PAUSE");	 
 }


 
