// autore : paolo
// versione e data: 1 del 10-08-2013
// descrizione : disegna il tuo nome
// Sviluppato con: Dev-C++ 5.4.1                 
#include <stdio.h>

main()
{

  printf("\n**************************************");
  printf("\n* PPPPPP AAAAAA OOOOOO LL     OOOOOO *");
  printf("\n* PP  PP AA  AA OO  OO LL     OO  OO *");
  printf("\n* PPPPPP AAAAAA OO  OO LL     OO  OO *");
  printf("\n* PP     AA  AA OO  OO LL     OO  OO *");
  printf("\n* PP     AA  AA OOOOOO LLLLLL OOOOOO *");
  printf("\n**************************************\n\n");

  
 printf("\n\n");
}
