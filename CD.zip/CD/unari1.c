// autore : paolo
// versione e data: 1 del 10-08-2014
// descrizione :  test sugli operatori unari 
// Sviluppato con: Dev-C++ 5.4.1               
#include <stdio.h>
main()
{
int var1=10;

  ++var1;
  printf ("\n++var1; %d", var1);

  var1++;
  printf ("\nvar1++; %d", var1);
  
  var1+1;
  printf ("\nvar1+1; %d", var1);
  
 // 1+var1;
  printf ("\n1+var1; %d", var1);

  printf("\n\n");
 // system("PAUSE");
}
