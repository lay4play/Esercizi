
#include <iostream>
using namespace std;
int main()
{
  int num1;
  cout << "Inserisci un numero  \t: ";
  cin >> num1;
  if (num1 >= 0)
    cout << "il numero e' positivo" << endl;
  else
    cout << "il numero e' negativo" << endl;

}
/* File: positivo.c                           */
/* Time-stamp: "2018-06-06 03:26:06 paolo"    */
/* Scopo: uso di if/else                      */
// Sviluppato con: Dev-C++ 5.11       





