/* Sviluppato con  : Dev-C++ 5.4.1    */

#include <iostream>    // libreria specifica del C++ per l'IO
using namespace std;   // necessaria per dichiarare l'uso dello spazio 
                       // dei nomi della libreria standard
main() 
{
  cout << " 44 gatti" ;
  cout << " in fila per 6 col resto di 2 " ;
  cout << "\n\n" ;
  cout << " 6 x 7 = 42, piu' 2 fa 44" ;
 
  cout << "\n\n" ; 
}
