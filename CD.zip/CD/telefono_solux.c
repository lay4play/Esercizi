// descrizione: scrivi il tuo numero di telefono
// versione e data: 1 del 10-08-2011
// autore : paolo
// Sviluppato con: Dev-C++ 5.4.1               
#include <stdio.h>

main()
{

  printf ("\n  33333  33333  99999   22222   888    11  00000  55555  77777 \n");
  printf ("      3      3  9   9       2  8   8  1 1  0   0  5          7 \n");
  printf ("    333    333  99999   22222   888     1  0   0  55555     7  \n");
  printf ("      3      3      9   2      8   8    1  0   0      5    7   \n");
  printf ("  33333  33333  99999 o 22222   888     1  00000  55555   7    \n" );


  printf("\n\n telefonami o messaggiami :) ... \n\n");

  //system("PAUSE");	
}
