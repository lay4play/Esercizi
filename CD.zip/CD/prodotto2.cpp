/* Sviluppato con  : Dev-C++ 5.4.1    */
#include <iostream>    // libreria specifica del C++ per l'IO
//#include <cstdlib>     // libreria che dichiara la funzione system
using namespace std;
main()
{
 int num1, num2;
  cout << "Programma che calcola il prodotto di due numeri";
  cout << "\nInserisci il moltiplicando   : ";
  cin  >> num1;
  cout << "Inserisci il moltiplicatore  : ";
  cin  >> num2;
  cout << "Il prodotto calcolato e\'     :" << num1*num2;
  
  cout << "\n\n";
//  system("PAUSE");
}
 
