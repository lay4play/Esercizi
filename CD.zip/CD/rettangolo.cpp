#include <iostream>     // libreria per l'IO
using namespace std;    // spazio dei nomi
int main(){
 int area;       // dichiarazione  variabili
 int latoA;
 int latoB;
 latoA = 10;  // inizializzazione  variabili
 latoB =  5;
 area  = latoA * latoB; // calcolo dell'area
 cout << "Area: " << area << endl; // a capo 
 cout << "\n\n";        // due righe bianche
}

// autore : paolo
// versione e data: 1 del 10-08-2018
// descrizione : calcolo dell'area di un rettangolo
/* sviluppato con  : Dev-C++ 5.11    */

