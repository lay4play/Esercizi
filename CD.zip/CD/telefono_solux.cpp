// autore : paolo
// versione e data: 1 del 10-08-2018
// descrizione : disegna un albero di natale
// Sviluppato con: Dev-C++ 5.4.1                 
#include <iostream>
using namespace std;

int main(){

  cout << "\n  33333  33333  99999   22222   888    11  00000  55555  77777 \n";
  cout << "      3      3  9   9       2  8   8  1 1  0   0  5          7 \n";
  cout << "    333    333  99999   22222   888     1  0   0  55555     7  \n";
  cout << "      3      3      9   2      8   8    1  0   0      5    7   \n";
  cout << "  33333  33333  99999 o 22222   888     1  00000  55555   7    \n";


  cout << "\n\n telefonami o messaggiami :) ... \n\n";

  //system("PAUSE");	
}

