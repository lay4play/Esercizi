// autore : paolo
// versione e data: 1 del 10-12-2013
// descrizione : disegna un diamante 
// Sviluppato con: Dev-C++ 5.4.1                 
#include <stdio.h>

main()
{
  printf("   *     *   \n");
  printf("  ***   ***  \n");
  printf(" ***** ***** \n");
  printf("  ***   ***  \n");
  printf("   *     *   \n");
  printf("             \n");
  printf("   *     *   \n");
  printf("  ***   ***  \n");
  printf(" ***** ***** \n");
  printf("  ***   ***  \n");
  printf("   *     *   \n");

  printf("\n\n");
}
