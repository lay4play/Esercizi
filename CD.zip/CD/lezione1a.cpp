/* Sviluppato con  : Dev-C++ 5.4.1    */
#include <iostream>   // include le funzioni di IO
using namespace std;
#include <conio.h>    // include le funzioni get()
#include <cstdlib>    // include le funzioni system
main()
{
  printf ("ciao mondo C e C++");
  printf ("\n\n");
  system("PAUSE");  
}
  
