#include <stdio.h>
// direttiva define
#define PIGRECO 3.1415
#define NUM_NANI 7 
#define CAMBIO_LIRA_EURO 1936.27
#define FALSE 0  
#define TRUE  1
#define SALUTO "Ciao Mondo"



