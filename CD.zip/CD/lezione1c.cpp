/* Sviluppato con  : Dev-C++ 5.4.1    */
#include <iostream>   // include le funzioni di IO
using namespace std;

main() 
{
  cout << "ciao mondo C++ (o CPP)" ; 

  cout << "\n\n" ; 
}
